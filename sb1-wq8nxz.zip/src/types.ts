export interface Player {
  id: number;
  name: string;
  timestamp: string; // Changed from Date to string to avoid serialization issues
}

export interface GameDetails {
  date: string;
  time: string;
  revolutLink: string;
}