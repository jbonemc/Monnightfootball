import React from 'react';
import { GameDetails } from '../types';

interface AdminPanelProps {
  gameDetails: GameDetails;
  setGameDetails: React.Dispatch<React.SetStateAction<GameDetails>>;
}

function AdminPanel({ gameDetails, setGameDetails }: AdminPanelProps) {
  return (
    <div className="mt-8 p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Admin Panel</h2>
      <div className="space-y-4">
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">
            Game Date
          </label>
          <input
            type="date"
            id="date"
            value={gameDetails.date}
            onChange={(e) => setGameDetails({ ...gameDetails, date: e.target.value })}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">
            Game Time
          </label>
          <input
            type="time"
            id="time"
            value={gameDetails.time}
            onChange={(e) => setGameDetails({ ...gameDetails, time: e.target.value })}
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label htmlFor="revolutLink" className="block text-sm font-medium text-gray-700 mb-1">
            Revolut Payment Link
          </label>
          <input
            type="url"
            id="revolutLink"
            value={gameDetails.revolutLink}
            onChange={(e) => setGameDetails({ ...gameDetails, revolutLink: e.target.value })}
            placeholder="https://revolut.me/..."
            className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
    </div>
  );
}

export default AdminPanel;